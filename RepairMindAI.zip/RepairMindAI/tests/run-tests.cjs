const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
require('../assets/diagnostic.js');
const { diagnose } = globalThis.RepairMindDiagnostic;
const cases = JSON.parse(fs.readFileSync(path.join(__dirname, '../data/sample-cases.json'), 'utf8'));
let failed = 0;
for (const sample of cases) {
  try {
    const result = diagnose(sample.input);
    assert.equal(result.status, sample.expectedStatus, 'status');
    if (sample.expectedTop) assert.equal(result.hypotheses[0].id, sample.expectedTop, 'top hypothesis');
    if (result.status === 'ranked') {
      assert.ok(result.hypotheses.length > 0, 'ranked result has a hypothesis');
      assert.ok(result.hypotheses.every(h => h.evidence.length > 0), 'each hypothesis cites supporting observations');
    }
    if (result.status === 'stop') assert.equal(result.hypotheses.length, 0, 'safety stop has no fault ranking');
    console.log(`PASS ${sample.id} ${sample.title}`);
  } catch (error) {
    failed++;
    console.log(`FAIL ${sample.id} ${sample.title}: ${error.message}`);
  }
}
console.log(`\n${cases.length - failed}/${cases.length} sample cases passed.`);
if (failed) process.exitCode = 1;
