# RepairMind AI SFIC innovation summary

Draft for transfer into the supplied Seva First Innovation Challenge Innovation Format. The form presents theme choices, two tracks, word-limited narrative fields, status choices, and team details. Applicant and mentor information was not supplied and is left for completion.

## Theme

**Proposed theme:** Swachh & Sustainable Bharat — Sustainable Technologies. Repair-first support may help people consider maintenance or repair before replacement. This is an intended direction; environmental or waste-reduction impact has not been measured.

## Track

**Proposed track:** Track 1 — Product / Technology.

## Title of the Innovation

**RepairMind AI: Safety-First Fan Troubleshooting Prototype**

## Problem Statement (500 words)

People who notice a household fan behaving abnormally may not know what observations matter, which possible causes fit those observations, or when they should stop using the appliance and seek qualified help. A simple symptom such as slow operation, humming, unusual noise, or intermittent operation can have more than one explanation. Guessing at a cause can be unhelpful, and attempting internal electrical checks without suitable training can be unsafe. Many users also need a clear way to distinguish a tentative possibility from a confirmed diagnosis.

RepairMind AI addresses this need with a browser-based, safety-first symptom triage prototype for electric fans. It gathers structured observations, asks relevant follow-up questions, and presents a small set of possible causes linked to the observations that support them. If the answers do not provide enough evidence, it says that a useful ranking is not possible. If the user reports smoke, burning smell or unusual heat, sparks or electric shock, damaged wiring, water exposure, or repeated breaker trips, it stops diagnosis and directs the user toward safe escalation.

The current prototype is a demonstration of a transparent rule-based approach. It does not establish how common fan faults are, replace a repair professional, or prove that a proposed cause is correct. The project’s next challenge is to validate the questions, rules, and safety wording with qualified repair and electrical-safety reviewers and with intended users before considering deployment.

## Problem Description (500 words)

Electric fans are familiar household appliances, but a symptom alone does not reliably identify a fault. Weak airflow might relate to an external obstruction, mechanical drag, a motor or starting component, or another model-specific issue. A humming sound with no rotation can be consistent with more than one internal problem. A rattle may come from a mechanical part, a mounting issue, or something else. A user-facing guide should therefore collect context and explain uncertainty rather than claim certainty from a single symptom.

Safety also changes what a useful diagnostic interaction should do. A report of smoke, a burning smell, sparks, electric shock, a damaged cord or plug, water exposure, or a repeatedly tripping breaker should interrupt ordinary troubleshooting. The user should not be encouraged to repeat the fault, open the housing, or test live electrical parts. A digital prototype can encode this as an explicit stop condition and keep any ordinary observations separate from internal repair work.

RepairMind AI is scoped to electric fans and to information that a user can report without tools or disassembly. It does not yet cover other appliances, individual fan models, component measurements, repair instructions, or a service-provider network. No field research, deployment, measured user outcomes, or repair accuracy results are available for this submission. The project therefore presents the problem and the prototype’s intended use without making prevalence, savings, safety, or performance claims.

## Idea / Solution Description (500 words)

RepairMind AI is a small browser application for structured electric-fan symptom triage. The user selects a main symptom and answers adaptive follow-up questions about visible or audible behavior. The application then applies hand-authored rules in a transparent scoring system. Each displayed possibility includes the specific observations that raised it, an explanation of why it may fit, and a safe next step that avoids internal electrical work.

The workflow has three outcomes. First, when one or more declared warning signs are reported, a safety stop takes priority and no fault ranking is shown. Second, when the available answers do not support a useful candidate, the application reports insufficient evidence. Third, otherwise, it shows up to three possibilities ordered by relative rule support. The ranking is not a probability, and the interface states that it is not confirmation or professional diagnosis.

The current prototype uses plain HTML, CSS, and JavaScript and runs in a browser without installation or a server. Its logic can be inspected in the source files. Eight illustrative sample cases exercise example ranked outcomes, insufficient evidence, and safety escalation. The completed automated run is recorded in the project’s test-results file. Those tests check expected behavior for the included examples only. They are not user testing, field testing, electrical safety certification, or evidence of real-world diagnostic accuracy.

## Expected Impact (500 words)

If later validated and improved, RepairMind AI could help a user organize symptoms before speaking with a repair professional, understand why several causes remain possible, and recognize warning signs that call for stopping use and seeking qualified help. Its repair-first framing is intended to support consideration of maintenance and repair. A future, properly evaluated version might help improve access to understandable appliance guidance.

These are expected benefits, not measured outcomes. The current prototype has not been evaluated for diagnosis accuracy, avoided replacements, cost savings, electrical injury reduction, accessibility, or user comprehension. It has not been deployed in a home, institution, repair shop, or community. No environmental benefit or adoption claim is made. The prototype is limited to a small set of fan symptoms and illustrative rule logic.

To assess impact responsibly, future work would need qualified review of electrical safety content, validation against documented repair cases across fan types, usability sessions with intended users, accessibility and device testing, and a monitored pilot with clear escalation paths. Any impact measures should be defined before that work and reported with sample size and limitations. Until then, the project’s present result is a working software prototype and a set of automated checks against its included examples.

## Current Status of the Idea

**Select: Prototype Developed.** A browser-based working prototype and its source files are included. The software rules were also run against eight included sample cases; all passed in the recorded run. If the form permits a note, add: “Automated sample-case checks only; not user, field, or professional validation.” Do not select “Pilot implemented.” “Prototype Tested” should only be selected if the committee accepts automated software tests as prototype testing; otherwise retain “Prototype Developed” and explain the limited test run in the methodology/evidence fields.

## Methodology

The prototype uses structured symptom and observation inputs with symptom-dependent follow-up questions. A transparent, hand-authored scoring rule associates selected observations with candidate fan issues. Candidates require supporting evidence and are ordered by relative score; these scores are not probabilities. A separate safety rule checks for smoke/fire, burning smell or unusual heat, sparks/electric shock, damaged cord/plug, water exposure, or repeated breaker trips and immediately returns stop-and-escalate guidance. When evidence is too sparse, the system returns an insufficient-evidence outcome. The included automated sample checks cover eight scenarios. No user study, field deployment, or independent safety review has been performed.

## Prototype

**RepairMind AI web prototype for electric-fan symptom triage.** Open `index.html` in a browser. The source, run instructions, rule logic, sample dataset, and test results are in the accompanying `RepairMindAI` project folder.

## Video Link

Not provided. Add a demonstration video link only if one is recorded and reviewed by the applicant.

## Any Other Evidence

- Source project and README with browser run instructions.
- Eight illustrative sample test cases and actual test run record.
- Safety wording informed by the U.S. Consumer Product Safety Commission’s [Guide to Home Wiring Hazards](https://www.cpsc.gov/s3fs-public/518.pdf), including its direction to stop using appliances with damaged cords and obtain qualified repair. This reference does not validate the prototype’s diagnostic rules.

## Link to Supporting Documents

Attach or link the `RepairMindAI` project folder and this summary using the submission portal’s supported file-sharing method. No public hosting link has been created.

## Team details

Complete these Innovation Format fields before submission; no information was provided in the request:

- **Name of the Team:** To be completed by applicant.
- **Team Leader:** Name, register number, department and year, email, phone, and mentor — to be completed by applicant.
- **Number of team members:** To be completed by applicant.
- **Team members (2–6):** Names, register numbers, departments, and years — to be completed by applicant.
